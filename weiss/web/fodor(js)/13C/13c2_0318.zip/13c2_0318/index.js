const express = require('express')
const mysql = require('mysql')
const app = express()
const port = 3000

app.listen(port, () => {
    console.log(`Server is running on port: ${port}`)
})

app.use(express.json())

app.get('/', (req, res) => {
    res.send('Ez egy nodejs server!')
})

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: '13c1'
})

db.connect((err) => {
    if (err) {
        console.log('Database connection failed:', err.message)
    } else {
        console.log('Database connection successful')
    }
})

app.get('/users', (req, res) => {
    db.query('SELECT * FROM users', (err, result) => {
        if (err) {
            res.send(err.message)
        } else {
            res.send(result)
        }
    })
})

app.get('/users/:id', (req, res) => {
    const uid = req.params.id
    db.query(`SELECT * FROM users WHERE id = ${uid}`, (err, result) => {
        if (err) {
            res.send(err.message)
        } else if (result == "") {
            res.send('Nincs ilyen felhasználó.')        
        } else {
            res.json(result)            
        }
    })
})

app.post('/users', (req, res) => {
    const uname = req.body.name
    const uemail = req.body.email
    db.query(`INSERT INTO users (name, email) VALUES ('${uname}', '${uemail}')`, (err) => {
        if (err) {
            res.send(err.message)
        } else {
            res.json({uname, uemail})
        }
    })
})

app.delete('/users/:id', (req, res) => {
    const uid = req.params.id
    db.query(`DELETE FROM users WHERE id = ${uid}`, (err, result) => {
        if (err) {
            res.send("Nem sikerült törölni a felhasználót", err.message)
        } else if (result.affectedRows == 0) {
            res.send("Nincs ilyen felhasználó")
        } else {
            res.send("Sikerült törölni a felhasználót")
        }
    })
})

app.put('/users/:id', (req, res) => {
    const uid = req.params.id
    const uname = req.body.name
    const uemail = req.body.email
    db.query(`UPDATE users SET name = '${uname}', email = '${uemail}' WHERE id = ${uid}`, (err, result) => {
        if (err) {
            res.send(err.message)
        } else if (result.affectedRows == 0) {
            res.send("Nincs ilyen felhasználó")
        } else {
            res.json({uname, uemail})
        }       
    })    
})