const express = require('express')
const mysql = require('mysql')
const app = express()
const port = 3000

app.listen(port, () => {
    console.log(`Server is running on port: ${port}`)
})

app.get('/', (req, res) => {
    res.send('Ez egy nodejs server!')
})

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: '13c1'
})

db.connect((err) => {
    if (err) {
        console.log('Database connection failed:', err.message)
    } else {
        console.log('Database connection successful')
    }
})

app.get('/users', (req, res) => {
    db.query('SELECT * FROM users', (err, result) => {
        if (err) {
            res.send(err.message)
        } else {
            res.send(result)
        }
    })
})

